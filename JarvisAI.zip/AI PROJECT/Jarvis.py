import speech_recognition as sr
import pyttsx3
import requests
import json
import re
import os
import subprocess
import webbrowser
import threading
import tkinter as tk
from tkinter import ttk, scrolledtext

API_KEY = "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"
API_URL = "https://openrouter.ai/api/v1/chat/completions"

HEADERS = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}

engine = pyttsx3.init()
engine.setProperty("rate", 180)
recognizer = sr.Recognizer()
microphone = sr.Microphone()

def speak(text):
    engine.say(text)
    engine.runAndWait()

def clean_response(text):
    text = re.sub(r'\\n|\n|\r', ' ', text)
    text = re.sub(r'[*_#>\[\]{}|]', '', text)
    text = re.sub(r'\s{2,}', ' ', text)
    return text.strip()

def chat(prompt):
    try:
        data = {
            "model": "deepseek/deepseek-r1-0528-qwen3-8b:free",
            "messages": [
                {
                    "role": "system",
                    "content": "You are Jarvis, an intelligent AI assistant. Speak clearly and in a natural tone."
                },
                {"role": "user", "content": prompt}
            ]
        }
        response = requests.post(API_URL, headers=HEADERS, data=json.dumps(data))
        if response.status_code == 200:
            result = response.json()
            raw_answer = result["choices"][0]["message"]["content"]
            return clean_response(raw_answer)
        else:
            return f"API error: {response.status_code}"
    except Exception as e:
        return f"Exception: {str(e)}"

def shutdown():
    speak("Shutting down the system.")
    os.system("shutdown /h")

def open_chrome():
    speak("Opening Chrome.")
    path = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"
    subprocess.Popen([path])

def search_google(query):
    speak(f"Searching Google for {query}")
    url = f"https://www.google.com/search?q={query}"
    webbrowser.open(url)

def open_folder(folder_name):
    speak(f"Opening folder {folder_name}")
    folder_path = os.path.join("C:\\Users\\Ezio\\Desktop\\JarvisFolder\\", folder_name)
    if os.path.exists(folder_path):
        os.startfile(folder_path)
    else:
        speak("Sorry, I can't find that folder.")

def gui_log(message):
    chat_box.config(state='normal')
    chat_box.insert(tk.END, message + "\n")
    chat_box.config(state='disabled')
    chat_box.yview(tk.END)

def type_response(response_text):
    chat_box.config(state='normal')
    chat_box.insert(tk.END, "Jarvis: ")
    chat_box.config(state='disabled')
    chat_box.yview(tk.END)

    def animate():
        for char in response_text:
            chat_box.config(state='normal')
            chat_box.insert(tk.END, char)
            chat_box.config(state='disabled')
            chat_box.yview(tk.END)
            chat_box.update()
            root.after(15)

    def speak_thread():
        speak(response_text)

    threading.Thread(target=animate, daemon=True).start()
    threading.Thread(target=speak_thread, daemon=True).start()

def process_command(command):
    command_lower = command.lower()

    if "shutdown" in command_lower:
        shutdown()
    elif "open chrome" in command_lower:
        open_chrome()
    elif "search for" in command_lower or "google" in command_lower:
        query = command_lower.replace("search for", "").replace("google", "").strip()
        if query:
            search_google(query)
    elif "open folder" in command_lower:
        folder = command_lower.replace("open folder", "").strip()
        open_folder(folder)
    else:
        response = chat(command)
        type_response(response)

def listen_and_respond():
    with microphone as source:
        recognizer.adjust_for_ambient_noise(source)
        gui_log("🎤 Listening for command...")
        audio = recognizer.listen(source)
    try:
        command = recognizer.recognize_google(audio)
        gui_log(f"You: {command}")
        process_command(command)
    except Exception as e:
        gui_log(f"❌ Could not understand. Error: {e}")

def start_voice():
    threading.Thread(target=listen_and_respond, daemon=True).start()

def submit_manual():
    user_input = user_entry.get()
    if user_input:
        gui_log(f"You: {user_input}")
        user_entry.delete(0, tk.END)
        process_command(user_input)

root = tk.Tk()
root.title("🧠 Jarvis AI Assistant")
root.geometry("720x540")
root.configure(bg="#1e1e1e")
root.resizable(False, False)

style = ttk.Style()
style.theme_use('clam')

style.configure("TButton",
                padding=6,
                relief="flat",
                background="#3a3a3a",
                foreground="white",
                font=("Segoe UI", 10, "bold"))
style.map("TButton",
          background=[("active", "#555555")])

style.configure("TEntry",
                padding=5,
                relief="flat",
                font=("Segoe UI", 11))

title_label = tk.Label(root, text="Jarvis AI", bg="#1e1e1e", fg="#00FFAA",
                       font=("Segoe UI", 20, "bold"))
title_label.pack(pady=10)

chat_box = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=80, height=20,
                                     font=("Consolas", 11), bg="#2b2b2b", fg="white",
                                     insertbackground="white", state="disabled", border=0)
chat_box.pack(padx=10, pady=5)

user_entry = ttk.Entry(root, width=60)
user_entry.pack(pady=10)

button_frame = tk.Frame(root, bg="#1e1e1e")
button_frame.pack()

listen_btn = ttk.Button(button_frame, text="🎤 Speak", command=start_voice)
listen_btn.grid(row=0, column=0, padx=10)

submit_btn = ttk.Button(button_frame, text="Send", command=submit_manual)
submit_btn.grid(row=0, column=1, padx=10)

exit_btn = ttk.Button(button_frame, text="Exit", command=root.destroy)
exit_btn.grid(row=0, column=2, padx=10)

speak("Hello, I am Jarvis. Ready when you are.")
gui_log("🟢 Jarvis is running. Say a command or type below.")

root.mainloop()
